This is not my resource pack, I have just added and changed some things in the original "LB Photo Realism" to make it fit to my server!
//MinerC1224